space for msc papers of interest, possible ideas we can draw from, or related work worth mentioning in the paper

- http://aclweb.org/anthology/C18-1329
- https://arxiv.org/pdf/1702.01932.pdf
- https://arxiv.org/pdf/1603.02514.pdf
- http://stanford.edu/~robinjia/pdf/naacl2018-drg.pdf, https://github.com/lijuncen/Sentiment-and-Style-Transfer
- https://web.stanford.edu/~jurafsky/pubs/neutrality.pdf
- [Approaching Neural Grammatical Error Correction as a Low-Resource Machine Translation Task](http://aclweb.org/anthology/N18-1055). Good ideas here, maybe try some?
- [A Multilayer Convolutional Encoder-Decoder Neural Network
for Grammatical Error Correction](https://arxiv.org/pdf/1801.08831.pdf): rescoring functions that might be good? handcrafted features + LM


TO READ
- https://arxiv.org/pdf/1805.11749.pdf
- http://aclweb.org/anthology/D18-1080
- http://aclweb.org/anthology/D18-1028
- http://www.aclweb.org/anthology/I17-2074
